package com.geodaily.app.data.local.dao

import androidx.room.*
import com.geodaily.app.data.local.entity.QuizQuestionEntity
import com.geodaily.app.data.local.entity.QuizResultEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface QuizDao {

    @Query("SELECT * FROM quiz_questions WHERE dayIndex = :dayIndex AND difficulty = :difficulty")
    suspend fun getQuestionsForDay(dayIndex: Int, difficulty: String): List<QuizQuestionEntity>

    @Query("SELECT * FROM quiz_questions")
    suspend fun getAllQuestions(): List<QuizQuestionEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(questions: List<QuizQuestionEntity>)

    @Query("SELECT COUNT(*) FROM quiz_questions")
    suspend fun count(): Int

    @Insert
    suspend fun insertResult(result: QuizResultEntity)

    @Query("SELECT * FROM quiz_results ORDER BY dateEpochDay DESC")
    fun getResultHistory(): Flow<List<QuizResultEntity>>

    @Query("SELECT * FROM quiz_results WHERE dateEpochDay = :epochDay LIMIT 1")
    suspend fun getResultForDay(epochDay: Long): QuizResultEntity?
}
