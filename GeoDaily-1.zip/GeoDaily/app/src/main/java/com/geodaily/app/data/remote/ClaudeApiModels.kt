package com.geodaily.app.data.remote

import com.google.gson.annotations.SerializedName

// Request/response models for the Anthropic Messages API (api.anthropic.com/v1/messages).
// The user supplies their own API key in Settings; it is stored locally via DataStore
// and sent only in the x-api-key header of requests made directly from the device.

data class ClaudeMessage(
    val role: String, // "user" or "assistant"
    val content: String
)

data class ClaudeRequest(
    val model: String = "claude-sonnet-4-6",
    @SerializedName("max_tokens") val maxTokens: Int = 600,
    val system: String,
    val messages: List<ClaudeMessage>
)

data class ClaudeContentBlock(
    val type: String,
    val text: String?
)

data class ClaudeResponse(
    val content: List<ClaudeContentBlock>?,
    val error: ClaudeError?
)

data class ClaudeError(
    val type: String?,
    val message: String?
)
