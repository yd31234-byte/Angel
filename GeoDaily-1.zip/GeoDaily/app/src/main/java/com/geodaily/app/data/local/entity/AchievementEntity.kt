package com.geodaily.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A single unlockable badge shown on the profile/achievements screen. */
@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val description: String,
    val iconName: String,
    val isUnlocked: Boolean = false,
    val unlockedAtEpochDay: Long? = null,
    val requiredValue: Int,
    val type: String // STREAK, QUIZ_COUNT, XP, PERFECT_SCORE, FACTS_READ
)
