package com.geodaily.app.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.geodaily.app.data.local.entity.AchievementEntity
import com.geodaily.app.data.local.entity.QuizResultEntity
import com.geodaily.app.data.local.entity.UserStatsEntity
import com.geodaily.app.data.repository.QuizRepository
import com.geodaily.app.data.repository.StatsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class ProfileUiState(
    val stats: UserStatsEntity? = null,
    val achievements: List<AchievementEntity> = emptyList(),
    val quizHistory: List<QuizResultEntity> = emptyList()
)

@HiltViewModel
class ProfileViewModel @Inject constructor(
    statsRepository: StatsRepository,
    quizRepository: QuizRepository
) : ViewModel() {

    val uiState: StateFlow<ProfileUiState> = combine(
        statsRepository.observeStats(),
        statsRepository.observeAchievements(),
        quizRepository.getHistory()
    ) { stats, achievements, history ->
        ProfileUiState(stats = stats, achievements = achievements, quizHistory = history)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProfileUiState())
}
