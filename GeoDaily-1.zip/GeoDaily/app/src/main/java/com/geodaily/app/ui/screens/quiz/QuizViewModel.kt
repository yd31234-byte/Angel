package com.geodaily.app.ui.screens.quiz

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.geodaily.app.data.local.entity.QuizQuestionEntity
import com.geodaily.app.data.repository.QuizRepository
import com.geodaily.app.data.repository.StatsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class QuizPhase { DIFFICULTY_SELECT, IN_PROGRESS, ALREADY_DONE, FINISHED }

data class QuizUiState(
    val phase: QuizPhase = QuizPhase.DIFFICULTY_SELECT,
    val questions: List<QuizQuestionEntity> = emptyList(),
    val currentIndex: Int = 0,
    val selectedOptionIndex: Int? = null,
    val hasAnswered: Boolean = false,
    val score: Int = 0,
    val difficulty: String = "MEDIUM",
    val xpEarned: Int = 0
) {
    val currentQuestion: QuizQuestionEntity? get() = questions.getOrNull(currentIndex)
    val progress: Float get() = if (questions.isEmpty()) 0f else (currentIndex) / questions.size.toFloat()
}

@HiltViewModel
class QuizViewModel @Inject constructor(
    private val quizRepository: QuizRepository,
    private val statsRepository: StatsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(QuizUiState())
    val uiState: StateFlow<QuizUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            if (quizRepository.hasCompletedToday()) {
                _uiState.value = _uiState.value.copy(phase = QuizPhase.ALREADY_DONE)
            }
        }
    }

    fun startQuiz(difficulty: String) {
        viewModelScope.launch {
            val questions = quizRepository.getTodayQuestions(difficulty)
            _uiState.value = QuizUiState(
                phase = QuizPhase.IN_PROGRESS,
                questions = questions,
                difficulty = difficulty
            )
        }
    }

    fun selectOption(index: Int) {
        if (_uiState.value.hasAnswered) return
        val correct = _uiState.value.currentQuestion?.correctOptionIndex == index
        _uiState.value = _uiState.value.copy(
            selectedOptionIndex = index,
            hasAnswered = true,
            score = _uiState.value.score + if (correct) 1 else 0
        )
    }

    fun nextQuestion() {
        val state = _uiState.value
        val nextIndex = state.currentIndex + 1
        if (nextIndex >= state.questions.size) {
            finishQuiz()
        } else {
            _uiState.value = state.copy(
                currentIndex = nextIndex,
                selectedOptionIndex = null,
                hasAnswered = false
            )
        }
    }

    private fun finishQuiz() {
        viewModelScope.launch {
            val state = _uiState.value
            val multiplier = when (state.difficulty) { "HARD" -> 3; "MEDIUM" -> 2; else -> 1 }
            val xp = state.score * 10 * multiplier
            quizRepository.saveResult(state.score, state.questions.size, state.difficulty, xpEarned = xp)
            statsRepository.recordQuizCompletion(state.score, state.questions.size, state.difficulty)
            _uiState.value = state.copy(phase = QuizPhase.FINISHED, xpEarned = xp)
        }
    }
}
