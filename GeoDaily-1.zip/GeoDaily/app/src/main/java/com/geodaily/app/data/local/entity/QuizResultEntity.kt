package com.geodaily.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Stores the outcome of one completed daily quiz attempt. */
@Entity(tableName = "quiz_results")
data class QuizResultEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateEpochDay: Long,
    val score: Int,
    val totalQuestions: Int,
    val difficulty: String,
    val xpEarned: Int
)
