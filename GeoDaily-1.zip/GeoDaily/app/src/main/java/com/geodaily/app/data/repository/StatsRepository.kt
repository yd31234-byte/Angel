package com.geodaily.app.data.repository

import com.geodaily.app.data.local.SeedAchievements
import com.geodaily.app.data.local.dao.AchievementDao
import com.geodaily.app.data.local.dao.UserStatsDao
import com.geodaily.app.data.local.entity.AchievementEntity
import com.geodaily.app.data.local.entity.UserStatsEntity
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

/** Newly unlocked achievements returned so the UI can show a celebratory toast/animation. */
data class UnlockResult(val newlyUnlocked: List<AchievementEntity>, val leveledUp: Boolean)

@Singleton
class StatsRepository @Inject constructor(
    private val statsDao: UserStatsDao,
    private val achievementDao: AchievementDao
) {
    suspend fun seedIfNeeded() {
        if (achievementDao.count() == 0) achievementDao.insertAll(SeedAchievements.all())
        if (statsDao.getStats() == null) statsDao.upsert(UserStatsEntity())
    }

    fun observeStats(): Flow<UserStatsEntity?> = statsDao.observeStats()

    fun observeAchievements() = achievementDao.getAllAchievements()

    /** Call once per app-open/day to update streak based on last active date. */
    suspend fun registerDailyVisit(): UserStatsEntity {
        val stats = statsDao.getStats() ?: UserStatsEntity()
        val today = LocalDate.now().toEpochDay()
        val updated = when {
            stats.lastActiveEpochDay == today -> stats
            stats.lastActiveEpochDay == today - 1 -> stats.copy(
                currentStreak = stats.currentStreak + 1,
                longestStreak = maxOf(stats.longestStreak, stats.currentStreak + 1),
                lastActiveEpochDay = today
            )
            else -> stats.copy(
                currentStreak = 1,
                longestStreak = maxOf(stats.longestStreak, 1),
                lastActiveEpochDay = today
            )
        }
        statsDao.upsert(updated)
        return updated
    }

    suspend fun addFactRead(): UnlockResult {
        val stats = statsDao.getStats() ?: UserStatsEntity()
        val updated = awardXp(stats.copy(totalFactsRead = stats.totalFactsRead + 1), 5)
        statsDao.upsert(updated)
        return checkUnlocks("FACTS_READ", updated.totalFactsRead, updated)
    }

    suspend fun recordQuizCompletion(score: Int, total: Int, difficulty: String): UnlockResult {
        val stats = statsDao.getStats() ?: UserStatsEntity()
        val difficultyMultiplier = when (difficulty) { "HARD" -> 3; "MEDIUM" -> 2; else -> 1 }
        val earnedXp = score * 10 * difficultyMultiplier
        var updated = stats.copy(
            totalQuizzesTaken = stats.totalQuizzesTaken + 1,
            totalCorrectAnswers = stats.totalCorrectAnswers + score
        )
        updated = awardXp(updated, earnedXp)
        statsDao.upsert(updated)

        val quizUnlock = checkUnlocks("QUIZ_COUNT", updated.totalQuizzesTaken, updated)
        val perfectUnlock = if (score == total) {
            val perfectCount = achievementDao.getLockedByType("PERFECT_SCORE").size
            checkUnlocks("PERFECT_SCORE", (SeedAchievements.all().size - perfectCount), updated)
        } else UnlockResult(emptyList(), false)

        return UnlockResult(quizUnlock.newlyUnlocked + perfectUnlock.newlyUnlocked, quizUnlock.leveledUp)
    }

    private suspend fun awardXp(stats: UserStatsEntity, amount: Int): UserStatsEntity {
        val newXp = stats.xp + amount
        val newLevel = 1 + newXp / 200 // 200 XP per level
        return stats.copy(xp = newXp, level = newLevel)
    }

    private suspend fun checkUnlocks(type: String, currentValue: Int, stats: UserStatsEntity): UnlockResult {
        val today = LocalDate.now().toEpochDay()
        val candidates = achievementDao.getLockedByType(type).filter { currentValue >= it.requiredValue }
        candidates.forEach { achievementDao.unlock(it.id, today) }

        // Also check streak/XP achievements opportunistically, since they change on every visit.
        val streakCandidates = achievementDao.getLockedByType("STREAK").filter { stats.currentStreak >= it.requiredValue }
        streakCandidates.forEach { achievementDao.unlock(it.id, today) }
        val xpCandidates = achievementDao.getLockedByType("XP").filter { stats.xp >= it.requiredValue }
        xpCandidates.forEach { achievementDao.unlock(it.id, today) }

        return UnlockResult(candidates + streakCandidates + xpCandidates, false)
    }
}
