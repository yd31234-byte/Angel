package com.geodaily.app.ui.screens.quiz

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun QuizScreen(
    onFinished: (score: Int, total: Int, xp: Int) -> Unit,
    viewModel: QuizViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(state.phase) {
        if (state.phase == QuizPhase.FINISHED) {
            onFinished(state.score, state.questions.size, state.xpEarned)
        }
    }

    Box(Modifier.fillMaxSize().padding(16.dp)) {
        when (state.phase) {
            QuizPhase.DIFFICULTY_SELECT -> DifficultySelector(onSelect = viewModel::startQuiz)
            QuizPhase.ALREADY_DONE -> AlreadyDoneMessage()
            QuizPhase.IN_PROGRESS -> QuizInProgress(state, viewModel)
            QuizPhase.FINISHED -> {} // handled by LaunchedEffect navigation
        }
    }
}

@Composable
private fun DifficultySelector(onSelect: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Today's Geography Quiz", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("10 questions · choose your difficulty", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(32.dp))

        listOf("EASY" to "🌱 Easy", "MEDIUM" to "🌍 Medium", "HARD" to "🔥 Hard").forEach { (value, label) ->
            Button(
                onClick = { onSelect(value) },
                modifier = Modifier.fillMaxWidth(0.7f).padding(vertical = 6.dp)
            ) { Text(label) }
        }
    }
}

@Composable
private fun AlreadyDoneMessage() {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("✅ You've completed today's quiz!", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text("Come back tomorrow for 10 new questions.", style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun QuizInProgress(state: QuizUiState, viewModel: QuizViewModel) {
    val question = state.currentQuestion ?: return
    val animatedProgress by animateFloatAsState(targetValue = state.progress, label = "progress")

    Column(Modifier.fillMaxSize()) {
        LinearProgressIndicator(progress = animatedProgress, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text(
            "Question ${state.currentIndex + 1} of ${state.questions.size}",
            style = MaterialTheme.typography.labelLarge
        )
        Spacer(Modifier.height(16.dp))

        AnimatedContent(targetState = state.currentIndex, label = "question") { _ ->
            Column {
                Text(question.question, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(20.dp))

                question.options.forEachIndexed { index, option ->
                    OptionRow(
                        text = option,
                        index = index,
                        selectedIndex = state.selectedOptionIndex,
                        correctIndex = question.correctOptionIndex,
                        hasAnswered = state.hasAnswered,
                        onClick = { viewModel.selectOption(index) }
                    )
                    Spacer(Modifier.height(10.dp))
                }

                if (state.hasAnswered) {
                    Spacer(Modifier.height(8.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Text(
                            "💡 ${question.explanation}",
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = viewModel::nextQuestion, modifier = Modifier.fillMaxWidth()) {
                        Text(if (state.currentIndex + 1 == state.questions.size) "See Results" else "Next Question")
                    }
                }
            }
        }
    }
}

@Composable
private fun OptionRow(
    text: String,
    index: Int,
    selectedIndex: Int?,
    correctIndex: Int,
    hasAnswered: Boolean,
    onClick: () -> Unit
) {
    val containerColor = when {
        !hasAnswered -> MaterialTheme.colorScheme.surface
        index == correctIndex -> Color(0xFFBEE3C8)
        index == selectedIndex -> Color(0xFFF3C0C0)
        else -> MaterialTheme.colorScheme.surface
    }

    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(text, modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.bodyLarge)
    }
}
