package com.geodaily.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.geodaily.app.data.datastore.UserPreferences
import com.geodaily.app.ui.navigation.GeoDailyNavHost
import com.geodaily.app.ui.theme.GeoDailyTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var userPreferences: UserPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val themeMode by userPreferences.themeMode.collectAsState(
                initial = com.geodaily.app.data.datastore.ThemeMode.SYSTEM
            )
            GeoDailyTheme(themeMode = themeMode) {
                GeoDailyNavHost()
            }
        }
    }
}
