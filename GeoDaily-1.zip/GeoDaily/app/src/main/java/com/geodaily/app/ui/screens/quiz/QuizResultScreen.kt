package com.geodaily.app.ui.screens.quiz

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun QuizResultScreen(score: Int, total: Int, xp: Int, onDone: () -> Unit) {
    var animate by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (animate) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "scoreScale"
    )
    androidx.compose.runtime.LaunchedEffect(Unit) { animate = true }

    val message = when {
        score == total -> "Perfect score! 🌟"
        score >= total * 0.7 -> "Great job! 🎉"
        score >= total * 0.4 -> "Nice effort! 👍"
        else -> "Keep practicing! 💪"
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(message, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Text(
            "$score / $total",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.scale(scale)
        )
        Spacer(Modifier.height(12.dp))
        Text("+$xp XP earned", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(40.dp))
        Button(onClick = onDone) { Text("Back to Home") }
    }
}
