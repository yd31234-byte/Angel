package com.geodaily.app.ui.screens.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    onOpenMap: () -> Unit,
    viewModel: SearchViewModel = hiltViewModel()
) {
    val query by viewModel.currentQuery.collectAsState()
    val results by viewModel.results.collectAsState()

    Scaffold(topBar = { TopAppBar(title = { Text("Explore") }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = viewModel::onQueryChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search countries, rivers, mountains…") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onOpenMap) { Text("Open interactive world map →") }
            Spacer(Modifier.height(8.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(results, key = { it.id }) { fact ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(fact.category, style = MaterialTheme.typography.labelLarge)
                            Text(fact.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(fact.description, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
                        }
                    }
                }
                if (results.isEmpty()) {
                    item {
                        Text(
                            "No results yet — try a different search term.",
                            modifier = Modifier.padding(top = 24.dp)
                        )
                    }
                }
            }
        }
    }
}
