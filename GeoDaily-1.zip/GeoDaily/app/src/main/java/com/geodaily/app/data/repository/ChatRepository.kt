package com.geodaily.app.data.repository

import com.geodaily.app.data.datastore.UserPreferences
import com.geodaily.app.data.local.dao.ChatDao
import com.geodaily.app.data.local.entity.ChatMessageEntity
import com.geodaily.app.data.remote.ClaudeApiService
import com.geodaily.app.data.remote.ClaudeMessage
import com.geodaily.app.data.remote.ClaudeRequest
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

private const val TUTOR_SYSTEM_PROMPT = """
You are the GeoDaily AI Geography Tutor, a friendly and encouraging guide embedded in a
geography learning app. You specialize in countries, capitals, physical geography, climate,
oceans, mountains, rivers, and Earth science.

Rules you always follow:
1. Explain concepts simply and encourage curiosity.
2. If the user asks you to just reveal a quiz answer, do NOT give the final answer right away.
   Instead, give a helpful hint or ask a guiding question first, and only reveal the answer
   if the user explicitly says they still want it after the hint.
3. Keep answers concise (a few short paragraphs at most) since this is a mobile chat.
4. Be warm and supportive, especially with beginners.
"""

sealed class ChatResult {
    data class Success(val reply: String) : ChatResult()
    data class Error(val message: String) : ChatResult()
    object MissingApiKey : ChatResult()
}

/**
 * Talks to the Claude API directly from the device using a key the user pastes into
 * Settings. Conversation history is persisted locally via Room so it survives restarts.
 */
@Singleton
class ChatRepository @Inject constructor(
    private val chatDao: ChatDao,
    private val apiService: ClaudeApiService,
    private val userPreferences: UserPreferences
) {
    fun getMessages(): Flow<List<ChatMessageEntity>> = chatDao.getMessages()

    suspend fun sendMessage(userText: String): ChatResult {
        chatDao.insert(ChatMessageEntity(content = userText, isFromUser = true, timestamp = System.currentTimeMillis()))

        val apiKey = userPreferences.aiApiKey.first()
        if (apiKey.isNullOrBlank()) {
            return ChatResult.MissingApiKey
        }

        val history = chatDao.getMessages().first().takeLast(10).map {
            ClaudeMessage(role = if (it.isFromUser) "user" else "assistant", content = it.content)
        }

        return try {
            val response = apiService.sendMessage(
                apiKey = apiKey,
                request = ClaudeRequest(system = TUTOR_SYSTEM_PROMPT, messages = history)
            )
            if (response.isSuccessful) {
                val text = response.body()?.content?.firstOrNull { it.type == "text" }?.text
                    ?: "Sorry, I didn't quite catch that — could you rephrase your question?"
                chatDao.insert(ChatMessageEntity(content = text, isFromUser = false, timestamp = System.currentTimeMillis()))
                ChatResult.Success(text)
            } else {
                val errorMsg = response.body()?.error?.message ?: "Request failed (${response.code()})"
                ChatResult.Error(errorMsg)
            }
        } catch (e: Exception) {
            ChatResult.Error(e.message ?: "Network error. Please check your connection.")
        }
    }

    suspend fun clearHistory() = chatDao.clear()
}
