package com.geodaily.app.data.local.dao

import androidx.room.*
import com.geodaily.app.data.local.entity.FactEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FactDao {

    @Query("SELECT * FROM facts WHERE dayIndex = :dayIndex LIMIT 1")
    suspend fun getFactForDay(dayIndex: Int): FactEntity?

    @Query("SELECT * FROM facts ORDER BY dayIndex ASC")
    fun getAllFacts(): Flow<List<FactEntity>>

    @Query("SELECT * FROM facts WHERE isFavorite = 1 ORDER BY id DESC")
    fun getFavoriteFacts(): Flow<List<FactEntity>>

    @Query("SELECT * FROM facts WHERE title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%'")
    fun searchFacts(query: String): Flow<List<FactEntity>>

    @Query("UPDATE facts SET isFavorite = :isFavorite WHERE id = :factId")
    suspend fun setFavorite(factId: Long, isFavorite: Boolean)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(facts: List<FactEntity>)

    @Query("SELECT COUNT(*) FROM facts")
    suspend fun count(): Int
}
