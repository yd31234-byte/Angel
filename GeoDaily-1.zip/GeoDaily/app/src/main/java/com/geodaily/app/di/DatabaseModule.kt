package com.geodaily.app.di

import android.content.Context
import androidx.room.Room
import com.geodaily.app.data.local.GeoDailyDatabase
import com.geodaily.app.data.local.dao.AchievementDao
import com.geodaily.app.data.local.dao.ChatDao
import com.geodaily.app.data.local.dao.FactDao
import com.geodaily.app.data.local.dao.QuizDao
import com.geodaily.app.data.local.dao.UserStatsDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): GeoDailyDatabase =
        Room.databaseBuilder(context, GeoDailyDatabase::class.java, GeoDailyDatabase.DATABASE_NAME)
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideFactDao(db: GeoDailyDatabase): FactDao = db.factDao()
    @Provides fun provideQuizDao(db: GeoDailyDatabase): QuizDao = db.quizDao()
    @Provides fun provideAchievementDao(db: GeoDailyDatabase): AchievementDao = db.achievementDao()
    @Provides fun provideUserStatsDao(db: GeoDailyDatabase): UserStatsDao = db.userStatsDao()
    @Provides fun provideChatDao(db: GeoDailyDatabase): ChatDao = db.chatDao()
}
