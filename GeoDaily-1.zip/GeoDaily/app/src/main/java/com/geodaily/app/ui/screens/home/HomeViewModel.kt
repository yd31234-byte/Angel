package com.geodaily.app.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.geodaily.app.data.local.entity.FactEntity
import com.geodaily.app.data.local.entity.UserStatsEntity
import com.geodaily.app.data.repository.FactRepository
import com.geodaily.app.data.repository.QuizRepository
import com.geodaily.app.data.repository.StatsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val isLoading: Boolean = true,
    val todayFact: FactEntity? = null,
    val stats: UserStatsEntity? = null,
    val quizCompletedToday: Boolean = false,
    val newlyUnlockedTitles: List<String> = emptyList()
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val factRepository: FactRepository,
    private val quizRepository: QuizRepository,
    private val statsRepository: StatsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadHome()
    }

    fun loadHome() {
        viewModelScope.launch {
            factRepository.seedIfNeeded()
            quizRepository.seedIfNeeded()
            statsRepository.seedIfNeeded()

            val stats = statsRepository.registerDailyVisit()
            val fact = factRepository.getTodayFact()
            val completed = quizRepository.hasCompletedToday()

            _uiState.value = HomeUiState(
                isLoading = false,
                todayFact = fact,
                stats = stats,
                quizCompletedToday = completed
            )
        }
    }

    fun markFactRead() {
        viewModelScope.launch {
            val result = statsRepository.addFactRead()
            if (result.newlyUnlocked.isNotEmpty()) {
                _uiState.value = _uiState.value.copy(
                    newlyUnlockedTitles = result.newlyUnlocked.map { it.title }
                )
            }
        }
    }

    fun toggleFavorite(factId: Long, isFavorite: Boolean) {
        viewModelScope.launch {
            factRepository.toggleFavorite(factId, isFavorite)
            _uiState.value = _uiState.value.copy(
                todayFact = _uiState.value.todayFact?.copy(isFavorite = isFavorite)
            )
        }
    }

    fun dismissUnlockBanner() {
        _uiState.value = _uiState.value.copy(newlyUnlockedTitles = emptyList())
    }
}
