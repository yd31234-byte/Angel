package com.geodaily.app.data.local

import com.geodaily.app.data.local.entity.QuizQuestionEntity

/**
 * Offline quiz bank. Questions are grouped into "day buckets" of 10 per
 * difficulty; QuizRepository picks a bucket via (dayOfYear % bucketCount)
 * so a fresh-feeling set appears daily without any network call.
 */
object SeedQuiz {

    private fun q(
        question: String,
        options: List<String>,
        correct: Int,
        explanation: String,
        difficulty: String,
        category: String,
        dayIndex: Int
    ) = QuizQuestionEntity(
        question = question, options = options, correctOptionIndex = correct,
        explanation = explanation, difficulty = difficulty, category = category, dayIndex = dayIndex
    )

    fun all(): List<QuizQuestionEntity> = easyBucket0() + easyBucket1() +
        mediumBucket0() + mediumBucket1() + hardBucket0() + hardBucket1()

    private fun easyBucket0() = listOf(
        q("What is the largest continent by area?", listOf("Africa", "Asia", "Europe", "North America"), 1, "Asia covers about 30% of Earth's total land area, making it the largest continent.", "EASY", "Continents", 0),
        q("Which ocean is the largest?", listOf("Atlantic", "Indian", "Arctic", "Pacific"), 3, "The Pacific Ocean covers more area than all of Earth's landmasses combined.", "EASY", "Oceans", 0),
        q("What is the capital of France?", listOf("Lyon", "Marseille", "Paris", "Nice"), 2, "Paris has been France's capital for centuries and is its largest city.", "EASY", "Capitals", 0),
        q("Which desert is the largest hot desert in the world?", listOf("Gobi", "Sahara", "Kalahari", "Mojave"), 1, "The Sahara spans much of North Africa and is the largest hot desert on Earth.", "EASY", "Deserts", 0),
        q("What is the longest river in the world?", listOf("Amazon", "Yangtze", "Nile", "Mississippi"), 2, "The Nile, flowing through northeastern Africa, is traditionally considered the longest river.", "EASY", "Rivers", 0),
        q("Which country has the largest population?", listOf("United States", "India", "China", "Indonesia"), 1, "As of recent estimates, India has surpassed China as the most populous country.", "EASY", "Countries", 0),
        q("Mount Everest is located in which mountain range?", listOf("Andes", "Alps", "Himalayas", "Rockies"), 2, "Mount Everest sits on the border of Nepal and Tibet within the Himalayan range.", "EASY", "Mountains", 0),
        q("Which continent is known as the 'Land Down Under'?", listOf("Africa", "Australia", "South America", "Antarctica"), 1, "Australia earned this nickname because of its position in the Southern Hemisphere.", "EASY", "Continents", 0),
        q("What is the smallest country in the world by area?", listOf("Monaco", "San Marino", "Vatican City", "Liechtenstein"), 2, "Vatican City, at under half a square kilometer, is the world's smallest sovereign state.", "EASY", "Countries", 0),
        q("Which of these is a landlocked country?", listOf("Brazil", "Switzerland", "Japan", "Egypt"), 1, "Switzerland has no coastline and is entirely surrounded by other countries.", "EASY", "Countries", 0)
    )

    private fun easyBucket1() = listOf(
        q("What is the capital of Japan?", listOf("Osaka", "Kyoto", "Tokyo", "Yokohama"), 2, "Tokyo has served as Japan's capital and largest city since 1868.", "EASY", "Capitals", 1),
        q("Which continent has the most countries?", listOf("Asia", "Africa", "Europe", "South America"), 1, "Africa has 54 recognized sovereign states, more than any other continent.", "EASY", "Continents", 1),
        q("What is the tallest mountain in Africa?", listOf("Mount Kenya", "Mount Kilimanjaro", "Atlas Mountains", "Table Mountain"), 1, "Mount Kilimanjaro in Tanzania rises about 5,895 meters, the highest peak on the continent.", "EASY", "Mountains", 1),
        q("Which river flows through Egypt?", listOf("Congo", "Niger", "Nile", "Zambezi"), 2, "The Nile flows northward through Egypt before emptying into the Mediterranean Sea.", "EASY", "Rivers", 1),
        q("What is the largest island in the world?", listOf("Madagascar", "Borneo", "Greenland", "New Guinea"), 2, "Greenland, an autonomous territory of Denmark, is the world's largest island.", "EASY", "Maps", 1),
        q("Which country is shaped like a boot?", listOf("Spain", "Greece", "Italy", "Portugal"), 2, "Italy's distinctive boot shape makes it one of the most recognizable countries on a map.", "EASY", "Maps", 1),
        q("What color is not on the flag of Germany?", listOf("Black", "Red", "Gold", "Blue"), 3, "Germany's flag consists of three horizontal bands: black, red, and gold.", "EASY", "Flags", 1),
        q("Which ocean lies between the Americas and Europe/Africa?", listOf("Pacific", "Atlantic", "Indian", "Southern"), 1, "The Atlantic Ocean separates the Americas from Europe and Africa.", "EASY", "Oceans", 1),
        q("What is the driest continent (excluding Antarctica)?", listOf("Africa", "Asia", "Australia", "South America"), 2, "Australia has vast arid and semi-arid regions, making it the driest inhabited continent.", "EASY", "Climate", 1),
        q("Which country gifted the Statue of Liberty to the United States?", listOf("Spain", "France", "United Kingdom", "Italy"), 1, "France presented the statue in 1886 as a symbol of friendship between the two nations.", "EASY", "Landmarks", 1)
    )

    private fun mediumBucket0() = listOf(
        q("Which strait separates Europe from Africa?", listOf("Bering Strait", "Strait of Gibraltar", "Strait of Malacca", "Bosphorus"), 1, "The Strait of Gibraltar connects the Atlantic Ocean to the Mediterranean Sea at Europe and Africa's closest point.", "MEDIUM", "Maps", 0),
        q("Which country has three capital cities?", listOf("South Africa", "Bolivia", "Netherlands", "Sri Lanka"), 0, "South Africa splits governmental functions among Pretoria, Cape Town, and Bloemfontein.", "MEDIUM", "Capitals", 0),
        q("What is the name of the theoretical supercontinent that existed millions of years ago?", listOf("Laurasia", "Gondwana", "Pangaea", "Rodinia"), 2, "Pangaea was a single landmass that began breaking apart roughly 200 million years ago.", "MEDIUM", "Geology", 0),
        q("Which African lake is the source of the White Nile?", listOf("Lake Victoria", "Lake Chad", "Lake Tanganyika", "Lake Malawi"), 0, "Lake Victoria, Africa's largest lake, feeds the White Nile at Jinja, Uganda.", "MEDIUM", "Rivers", 0),
        q("The Atacama Desert is located primarily in which country?", listOf("Peru", "Chile", "Argentina", "Bolivia"), 1, "The Atacama runs along Chile's Pacific coast and is one of the driest places on Earth.", "MEDIUM", "Deserts", 0),
        q("Which mountain range separates Europe from Asia?", listOf("Alps", "Carpathians", "Ural Mountains", "Caucasus"), 2, "The Ural Mountains in Russia form a traditional geographical boundary between the two continents.", "MEDIUM", "Mountains", 0),
        q("Which country is both in Europe and Asia?", listOf("Georgia", "Turkey", "Kazakhstan", "All of these"), 3, "Turkey, Georgia, and Kazakhstan all have territory considered part of both continents.", "MEDIUM", "Countries", 0),
        q("What type of climate dominates the Amazon Basin?", listOf("Arid", "Tropical rainforest", "Mediterranean", "Tundra"), 1, "The Amazon Basin has a hot, humid tropical rainforest climate with heavy year-round rainfall.", "MEDIUM", "Climate", 0),
        q("Which volcano destroyed the Roman city of Pompeii?", listOf("Mount Etna", "Mount Vesuvius", "Stromboli", "Vulcano"), 1, "Mount Vesuvius erupted in 79 AD, burying Pompeii and Herculaneum in volcanic ash.", "MEDIUM", "Volcanoes", 0),
        q("Which sea is the saltiest large body of water on Earth?", listOf("Red Sea", "Dead Sea", "Caspian Sea", "Black Sea"), 1, "The Dead Sea's extreme salinity, roughly ten times that of the ocean, allows objects to float easily.", "MEDIUM", "Oceans", 0)
    )

    private fun mediumBucket1() = listOf(
        q("Which country has the most time zones?", listOf("Russia", "United States", "France", "China"), 2, "Counting all its overseas territories, France spans 12 time zones, more than any other country.", "MEDIUM", "Countries", 1),
        q("The Ring of Fire is associated with which type of activity?", listOf("Glaciation", "Volcanic and seismic activity", "Coral reef growth", "Desertification"), 1, "This Pacific Ocean belt experiences frequent earthquakes and hosts most of the world's active volcanoes.", "MEDIUM", "Geology", 1),
        q("Which river forms part of the border between the USA and Mexico?", listOf("Colorado River", "Rio Grande", "Mississippi River", "Snake River"), 1, "The Rio Grande runs along much of the Texas-Mexico border before reaching the Gulf of Mexico.", "MEDIUM", "Rivers", 1),
        q("What is the term for a narrow strip of land connecting two larger landmasses?", listOf("Peninsula", "Isthmus", "Archipelago", "Plateau"), 1, "An isthmus, like the Isthmus of Panama, links two larger areas of land.", "MEDIUM", "Maps", 1),
        q("Which country contains the source of the Amazon River?", listOf("Brazil", "Colombia", "Peru", "Ecuador"), 2, "The Amazon's most distant source is generally traced to glacial streams in the Peruvian Andes.", "MEDIUM", "Rivers", 1),
        q("Which biome is characterized by permanently frozen subsoil?", listOf("Taiga", "Tundra", "Steppe", "Savanna"), 1, "Tundra regions have a layer of permafrost beneath the surface that never fully thaws.", "MEDIUM", "Climate", 1),
        q("What is the capital of Canada?", listOf("Toronto", "Vancouver", "Ottawa", "Montreal"), 2, "Ottawa was chosen as the capital in 1857, partly for its position between English and French Canada.", "MEDIUM", "Capitals", 1),
        q("Which of these mountain ranges is the youngest geologically?", listOf("Appalachians", "Himalayas", "Urals", "Scottish Highlands"), 1, "The Himalayas began forming around 50 million years ago, making them geologically young and still rising.", "MEDIUM", "Mountains", 1),
        q("Which country is home to the Serengeti ecosystem?", listOf("Kenya", "Tanzania", "Uganda", "Zambia"), 1, "Most of the Serengeti lies within Tanzania, with the ecosystem extending into Kenya's Maasai Mara.", "MEDIUM", "Wildlife", 1),
        q("What is the name for wind-driven surface currents that circulate ocean water in large loops?", listOf("Tides", "Gyres", "Upwellings", "Tsunamis"), 1, "Gyres are large systems of rotating ocean currents driven by global wind patterns and Earth's rotation.", "MEDIUM", "Oceans", 1)
    )

    private fun hardBucket0() = listOf(
        q("Which line of latitude passes through the most countries in Africa?", listOf("Equator", "Tropic of Cancer", "Tropic of Capricorn", "Prime Meridian"), 0, "The Equator crosses through several African countries including Kenya, Uganda, and Gabon.", "HARD", "Maps", 0),
        q("Which river has the largest drainage basin in the world?", listOf("Nile", "Amazon", "Congo", "Mississippi"), 1, "The Amazon Basin drains about 7 million square kilometers, the largest of any river system.", "HARD", "Rivers", 0),
        q("What phenomenon causes the Atacama Desert's extreme dryness?", listOf("The rain shadow of the Andes", "Proximity to the equator", "High altitude alone", "Lack of ocean nearby"), 0, "The Andes block moisture from the Amazon, while a cold coastal current suppresses rainfall from the Pacific side.", "HARD", "Deserts", 0),
        q("Which tectonic plate boundary type is associated with the Mid-Atlantic Ridge?", listOf("Convergent", "Divergent", "Transform", "Subduction"), 1, "The Mid-Atlantic Ridge is a divergent boundary where new oceanic crust forms as plates pull apart.", "HARD", "Geology", 0),
        q("Which African country was formerly known as Abyssinia?", listOf("Sudan", "Somalia", "Ethiopia", "Eritrea"), 2, "Ethiopia was historically referred to as Abyssinia by outside powers for centuries.", "HARD", "Countries", 0),
        q("What is the approximate age of the Appalachian Mountains?", listOf("10 million years", "50 million years", "480 million years", "4.5 billion years"), 2, "The Appalachians formed roughly 480 million years ago, making them among the oldest mountain ranges on Earth.", "HARD", "Mountains", 0),
        q("Which current is primarily responsible for keeping Western Europe's climate mild?", listOf("Humboldt Current", "Gulf Stream", "Kuroshio Current", "Benguela Current"), 1, "The Gulf Stream transports warm tropical water northward, moderating temperatures across Western Europe.", "HARD", "Climate", 0),
        q("Which volcano's 1815 eruption caused the 'Year Without a Summer'?", listOf("Krakatoa", "Mount Tambora", "Mount Pinatubo", "Mount St. Helens"), 1, "Mount Tambora's eruption in Indonesia ejected enough ash to disrupt global climate patterns in 1816.", "HARD", "Volcanoes", 0),
        q("Which sea is technically the world's largest lake by surface area?", listOf("Aral Sea", "Caspian Sea", "Dead Sea", "Sea of Galilee"), 1, "Though called a sea, the Caspian is landlocked and classified by many geographers as the largest lake on Earth.", "HARD", "Oceans", 0),
        q("Which desert expands seasonally due to the Harmattan winds?", listOf("Kalahari", "Sahara", "Namib", "Gobi"), 1, "The Harmattan carries dry, dusty air from the Sahara across West Africa during certain months.", "HARD", "Deserts", 0)
    )

    private fun hardBucket1() = listOf(
        q("Which strait connects the Mediterranean Sea to the Black Sea?", listOf("Strait of Hormuz", "Bosphorus", "Strait of Dover", "Skagerrak"), 1, "The Bosphorus, running through Istanbul, links the Sea of Marmara to the Black Sea.", "HARD", "Maps", 1),
        q("What causes the Coriolis effect to influence wind and ocean currents?", listOf("Earth's magnetic field", "Earth's rotation", "The Moon's gravity", "Solar radiation"), 1, "Earth's rotation deflects moving air and water, curving them right in the Northern Hemisphere and left in the Southern.", "HARD", "Geology", 1),
        q("Which country has land in both the Northern and Southern Hemispheres, and both Eastern and Western Hemispheres?", listOf("Brazil", "Kiribati", "Indonesia", "Ecuador"), 1, "Kiribati's scattered islands span the equator and the 180th meridian, placing it in all four hemispheres.", "HARD", "Countries", 1),
        q("What is the term for the boundary where the Pacific and Nazca plates converge, producing the Andes?", listOf("Divergent boundary", "Transform fault", "Subduction zone", "Rift valley"), 2, "The Nazca Plate subducts beneath the South American Plate, driving the uplift of the Andes and volcanic activity.", "HARD", "Mountains", 1),
        q("Which African rift feature is gradually splitting the continent in two?", listOf("Congo Basin", "East African Rift", "Great Escarpment", "Okavango Delta"), 1, "The East African Rift marks where the continent is slowly tearing apart along a divergent plate boundary.", "HARD", "Geology", 1),
        q("Which explorer's expedition first circumnavigated the globe, though he died before completing it?", listOf("Vasco da Gama", "Christopher Columbus", "Ferdinand Magellan", "James Cook"), 2, "Magellan died in the Philippines in 1521; his remaining crew completed the voyage under Juan Sebastián Elcano.", "HARD", "Landmarks", 1),
        q("Which climate classification describes most of the Amazon rainforest under the Köppen system?", listOf("Aw", "Af", "BWh", "Cfb"), 1, "The Af classification denotes a tropical rainforest climate with no dry season and consistently high rainfall.", "HARD", "Climate", 1),
        q("Which ocean trench is the deepest point on Earth's surface?", listOf("Puerto Rico Trench", "Java Trench", "Mariana Trench", "Kermadec Trench"), 2, "The Mariana Trench's Challenger Deep reaches nearly 11,000 meters below sea level.", "HARD", "Oceans", 1),
        q("Which country's flag features a design derived from an ancient sun symbol called the Surya?", listOf("India", "Nepal", "Bangladesh", "Japan"), 0, "India's flag features the Ashoka Chakra, a 24-spoke wheel with roots in ancient Indian solar symbolism.", "HARD", "Flags", 1),
        q("Which desert plateau in South America is known for its otherworldly salt flats?", listOf("Altiplano", "Patagonian steppe", "Gran Chaco", "Pampas"), 0, "The Altiplano, spanning Bolivia and Peru, hosts the Salar de Uyuni, the world's largest salt flat.", "HARD", "Deserts", 1)
    )
}
