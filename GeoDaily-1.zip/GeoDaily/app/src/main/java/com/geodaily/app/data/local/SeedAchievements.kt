package com.geodaily.app.data.local

import com.geodaily.app.data.local.entity.AchievementEntity

object SeedAchievements {
    fun all(): List<AchievementEntity> = listOf(
        AchievementEntity(id = "streak_3", title = "Getting Started", description = "Maintain a 3-day learning streak", iconName = "LocalFireDepartment", requiredValue = 3, type = "STREAK"),
        AchievementEntity(id = "streak_7", title = "Weekly Wanderer", description = "Maintain a 7-day learning streak", iconName = "LocalFireDepartment", requiredValue = 7, type = "STREAK"),
        AchievementEntity(id = "streak_30", title = "Globe Trotter", description = "Maintain a 30-day learning streak", iconName = "LocalFireDepartment", requiredValue = 30, type = "STREAK"),
        AchievementEntity(id = "quiz_1", title = "First Steps", description = "Complete your first daily quiz", iconName = "Quiz", requiredValue = 1, type = "QUIZ_COUNT"),
        AchievementEntity(id = "quiz_10", title = "Quiz Enthusiast", description = "Complete 10 daily quizzes", iconName = "Quiz", requiredValue = 10, type = "QUIZ_COUNT"),
        AchievementEntity(id = "quiz_50", title = "Quiz Master", description = "Complete 50 daily quizzes", iconName = "EmojiEvents", requiredValue = 50, type = "QUIZ_COUNT"),
        AchievementEntity(id = "perfect_1", title = "Perfect Score", description = "Get 10/10 on a daily quiz", iconName = "Star", requiredValue = 1, type = "PERFECT_SCORE"),
        AchievementEntity(id = "perfect_5", title = "Flawless Explorer", description = "Get 10/10 on 5 daily quizzes", iconName = "Star", requiredValue = 5, type = "PERFECT_SCORE"),
        AchievementEntity(id = "xp_100", title = "Rising Explorer", description = "Earn 100 total XP", iconName = "TrendingUp", requiredValue = 100, type = "XP"),
        AchievementEntity(id = "xp_1000", title = "World Class", description = "Earn 1000 total XP", iconName = "TrendingUp", requiredValue = 1000, type = "XP"),
        AchievementEntity(id = "facts_10", title = "Curious Mind", description = "Read 10 daily facts", iconName = "MenuBook", requiredValue = 10, type = "FACTS_READ"),
        AchievementEntity(id = "facts_50", title = "Geography Scholar", description = "Read 50 daily facts", iconName = "MenuBook", requiredValue = 50, type = "FACTS_READ")
    )
}
