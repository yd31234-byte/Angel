package com.geodaily.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Singleton row (id is always 1) holding the user's aggregate progress. */
@Entity(tableName = "user_stats")
data class UserStatsEntity(
    @PrimaryKey
    val id: Int = 1,
    val xp: Int = 0,
    val level: Int = 1,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val lastActiveEpochDay: Long = 0,
    val totalQuizzesTaken: Int = 0,
    val totalCorrectAnswers: Int = 0,
    val totalFactsRead: Int = 0,
    val displayName: String = "Explorer"
)
