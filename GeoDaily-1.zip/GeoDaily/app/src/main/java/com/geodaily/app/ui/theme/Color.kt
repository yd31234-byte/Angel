package com.geodaily.app.ui.theme

import androidx.compose.ui.graphics.Color

// GeoDaily palette — inspired by maps, oceans, and terrain.
val OceanBlue = Color(0xFF1B6CA8)
val OceanBlueLight = Color(0xFF5B9BD9)
val ForestGreen = Color(0xFF2E7D5B)
val SandGold = Color(0xFFE0A458)
val SunsetCoral = Color(0xFFE07A5F)
val DeepNavy = Color(0xFF0B2A45)

val LightPrimary = OceanBlue
val LightSecondary = ForestGreen
val LightTertiary = SandGold
val LightBackground = Color(0xFFF7F9FB)
val LightSurface = Color(0xFFFFFFFF)

val DarkPrimary = OceanBlueLight
val DarkSecondary = Color(0xFF6FBF97)
val DarkTertiary = Color(0xFFE8BC81)
val DarkBackground = Color(0xFF0E1620)
val DarkSurface = Color(0xFF16202C)
