package com.geodaily.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.geodaily.app.data.local.converter.Converters
import com.geodaily.app.data.local.dao.AchievementDao
import com.geodaily.app.data.local.dao.ChatDao
import com.geodaily.app.data.local.dao.FactDao
import com.geodaily.app.data.local.dao.QuizDao
import com.geodaily.app.data.local.dao.UserStatsDao
import com.geodaily.app.data.local.entity.AchievementEntity
import com.geodaily.app.data.local.entity.ChatMessageEntity
import com.geodaily.app.data.local.entity.FactEntity
import com.geodaily.app.data.local.entity.QuizQuestionEntity
import com.geodaily.app.data.local.entity.QuizResultEntity
import com.geodaily.app.data.local.entity.UserStatsEntity

/**
 * Single Room database for the app. All content (facts, quiz questions) is
 * seeded on first launch so the app is fully usable offline.
 */
@Database(
    entities = [
        FactEntity::class,
        QuizQuestionEntity::class,
        QuizResultEntity::class,
        AchievementEntity::class,
        UserStatsEntity::class,
        ChatMessageEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class GeoDailyDatabase : RoomDatabase() {
    abstract fun factDao(): FactDao
    abstract fun quizDao(): QuizDao
    abstract fun achievementDao(): AchievementDao
    abstract fun userStatsDao(): UserStatsDao
    abstract fun chatDao(): ChatDao

    companion object {
        const val DATABASE_NAME = "geodaily.db"
    }
}
