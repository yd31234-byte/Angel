package com.geodaily.app.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.geodaily.app.data.datastore.ThemeMode
import com.geodaily.app.data.datastore.UserPreferences
import com.geodaily.app.worker.NotificationScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val notificationsEnabled: Boolean = true,
    val notificationHour: Int = 9,
    val preferredDifficulty: String = "MEDIUM",
    val apiKey: String = ""
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val userPreferences: UserPreferences,
    private val notificationScheduler: NotificationScheduler
) : ViewModel() {

    val uiState: StateFlow<SettingsUiState> = combine(
        userPreferences.themeMode,
        userPreferences.notificationsEnabled,
        userPreferences.notificationHour,
        userPreferences.preferredDifficulty,
        userPreferences.aiApiKey
    ) { theme, notifEnabled, hour, difficulty, apiKey ->
        SettingsUiState(theme, notifEnabled, hour, difficulty, apiKey ?: "")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SettingsUiState())

    fun setThemeMode(mode: ThemeMode) = viewModelScope.launch { userPreferences.setThemeMode(mode) }

    fun setNotificationsEnabled(enabled: Boolean) = viewModelScope.launch {
        userPreferences.setNotificationsEnabled(enabled)
        if (enabled) notificationScheduler.scheduleDailyReminder(uiState.value.notificationHour)
        else notificationScheduler.cancel()
    }

    fun setNotificationHour(hour: Int) = viewModelScope.launch {
        userPreferences.setNotificationHour(hour)
        notificationScheduler.scheduleDailyReminder(hour)
    }

    fun setPreferredDifficulty(difficulty: String) = viewModelScope.launch {
        userPreferences.setPreferredDifficulty(difficulty)
    }

    fun setApiKey(key: String) = viewModelScope.launch { userPreferences.setAiApiKey(key) }
}
