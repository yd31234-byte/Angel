package com.geodaily.app.data.repository

import com.geodaily.app.data.local.SeedQuiz
import com.geodaily.app.data.local.dao.QuizDao
import com.geodaily.app.data.local.entity.QuizQuestionEntity
import com.geodaily.app.data.local.entity.QuizResultEntity
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.temporal.ChronoField
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class QuizRepository @Inject constructor(
    private val quizDao: QuizDao
) {
    suspend fun seedIfNeeded() {
        if (quizDao.count() == 0) {
            quizDao.insertAll(SeedQuiz.all())
        }
    }

    /** Returns today's 10 questions for the given difficulty, cycling through available day-buckets. */
    suspend fun getTodayQuestions(difficulty: String): List<QuizQuestionEntity> {
        val all = quizDao.getAllQuestions().filter { it.difficulty == difficulty }
        val buckets = all.groupBy { it.dayIndex }.values.toList()
        if (buckets.isEmpty()) return emptyList()
        val dayOfYear = LocalDate.now().get(ChronoField.DAY_OF_YEAR)
        val bucket = buckets[dayOfYear % buckets.size]
        return bucket.shuffled().take(10)
    }

    suspend fun hasCompletedToday(): Boolean {
        val epochDay = LocalDate.now().toEpochDay()
        return quizDao.getResultForDay(epochDay) != null
    }

    suspend fun saveResult(score: Int, total: Int, difficulty: String, xpEarned: Int) {
        quizDao.insertResult(
            QuizResultEntity(
                dateEpochDay = LocalDate.now().toEpochDay(),
                score = score,
                totalQuestions = total,
                difficulty = difficulty,
                xpEarned = xpEarned
            )
        )
    }

    fun getHistory(): Flow<List<QuizResultEntity>> = quizDao.getResultHistory()
}
