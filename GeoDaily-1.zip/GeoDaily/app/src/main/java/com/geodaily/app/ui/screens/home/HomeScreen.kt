package com.geodaily.app.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onStartQuiz: () -> Unit,
    onOpenMap: () -> Unit,
    onOpenFavorites: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(topBar = {
        TopAppBar(title = { Text("GeoDaily", fontWeight = FontWeight.Bold) })
    }) { padding ->
        if (state.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { StreakXpCard(state) }

            item {
                AnimatedVisibility(
                    visible = state.newlyUnlockedTitles.isNotEmpty(),
                    enter = fadeIn() + slideInVertically(),
                    exit = fadeOut()
                ) {
                    UnlockBanner(state.newlyUnlockedTitles) { viewModel.dismissUnlockBanner() }
                }
            }

            item {
                Text("Today's Fact", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }

            state.todayFact?.let { fact ->
                item {
                    DailyFactCard(
                        title = fact.title,
                        description = fact.description,
                        category = fact.category,
                        isFavorite = fact.isFavorite,
                        onFavoriteClick = { viewModel.toggleFavorite(fact.id, !fact.isFavorite) },
                        onRead = { viewModel.markFactRead() }
                    )
                }
            }

            item {
                Text("Keep Learning", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }

            item {
                QuickActionRow(
                    quizCompleted = state.quizCompletedToday,
                    onStartQuiz = onStartQuiz,
                    onOpenMap = onOpenMap,
                    onOpenFavorites = onOpenFavorites
                )
            }
        }
    }
}

@Composable
private fun StreakXpCard(state: HomeUiState) {
    val stats = state.stats
    Card(
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary)
                    )
                )
                .padding(20.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatColumn(
                    icon = Icons.Filled.LocalFireDepartment,
                    value = "${stats?.currentStreak ?: 0}",
                    label = "Day Streak"
                )
                StatColumn(
                    icon = Icons.Filled.Star,
                    value = "${stats?.xp ?: 0}",
                    label = "XP · Lvl ${stats?.level ?: 1}"
                )
            }
        }
    }
}

@Composable
private fun StatColumn(icon: androidx.compose.ui.graphics.vector.ImageVector, value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White)
        Spacer(Modifier.height(4.dp))
        Text(value, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        Text(label, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun UnlockBanner(titles: List<String>, onDismiss: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("🏆 Achievement unlocked!", fontWeight = FontWeight.Bold)
            titles.forEach { Text("• $it") }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Nice!") }
        }
    }
}

@Composable
private fun DailyFactCard(
    title: String,
    description: String,
    category: String,
    isFavorite: Boolean,
    onFavoriteClick: () -> Unit,
    onRead: () -> Unit
) {
    var hasMarkedRead by remember { mutableStateOf(false) }
    LaunchedEffect(title) {
        if (!hasMarkedRead) {
            onRead()
            hasMarkedRead = true
        }
    }

    ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                AssistChip(onClick = {}, label = { Text(category) })
                IconButton(onClick = onFavoriteClick) {
                    Icon(
                        if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isFavorite) MaterialTheme.colorScheme.error else LocalContentColor.current
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(description, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
private fun QuickActionRow(
    quizCompleted: Boolean,
    onStartQuiz: () -> Unit,
    onOpenMap: () -> Unit,
    onOpenFavorites: () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        ActionTile(
            icon = Icons.Filled.Quiz,
            label = if (quizCompleted) "Quiz Done ✓" else "Take Quiz",
            modifier = Modifier.weight(1f),
            onClick = onStartQuiz
        )
        ActionTile(
            icon = Icons.Filled.Map,
            label = "World Map",
            modifier = Modifier.weight(1f),
            onClick = onOpenMap
        )
        ActionTile(
            icon = Icons.Filled.Favorite,
            label = "Favorites",
            modifier = Modifier.weight(1f),
            onClick = onOpenFavorites
        )
    }
}

@Composable
private fun ActionTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clip(RoundedCornerShape(16.dp)),
        onClick = onClick
    ) {
        Column(
            Modifier.padding(vertical = 16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null)
            Spacer(Modifier.height(6.dp))
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}
