package com.geodaily.app.ui.screens.tutor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.geodaily.app.data.datastore.UserPreferences
import com.geodaily.app.data.local.entity.ChatMessageEntity
import com.geodaily.app.data.repository.ChatRepository
import com.geodaily.app.data.repository.ChatResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class TutorUiState(
    val messages: List<ChatMessageEntity> = emptyList(),
    val isSending: Boolean = false,
    val hasApiKey: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class TutorViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val userPreferences: UserPreferences
) : ViewModel() {

    private val isSending = MutableStateFlow(false)
    private val errorMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<TutorUiState> = combine(
        chatRepository.getMessages(),
        userPreferences.aiApiKey,
        isSending,
        errorMessage
    ) { messages, apiKey, sending, error ->
        TutorUiState(
            messages = messages,
            isSending = sending,
            hasApiKey = !apiKey.isNullOrBlank(),
            errorMessage = error
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TutorUiState())

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            isSending.value = true
            errorMessage.value = null
            when (val result = chatRepository.sendMessage(text)) {
                is ChatResult.Error -> errorMessage.value = result.message
                ChatResult.MissingApiKey -> errorMessage.value =
                    "Add your Claude API key in Settings to chat with the AI Tutor."
                is ChatResult.Success -> Unit
            }
            isSending.value = false
        }
    }

    fun clearChat() {
        viewModelScope.launch { chatRepository.clearHistory() }
    }
}
