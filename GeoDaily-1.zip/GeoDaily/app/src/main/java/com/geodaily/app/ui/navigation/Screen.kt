package com.geodaily.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.graphics.vector.ImageVector

/** Top-level destinations shown in the bottom navigation bar. */
sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Filled.Home)
    object Quiz : Screen("quiz", "Quiz", Icons.Filled.Quiz)
    object Tutor : Screen("tutor", "AI Tutor", Icons.Filled.Chat)
    object Search : Screen("search", "Explore", Icons.Filled.Search)
    object Profile : Screen("profile", "Profile", Icons.Filled.Person)

    companion object {
        val bottomBarScreens = listOf(Home, Quiz, Tutor, Search, Profile)
    }
}

/** Secondary destinations reached via navigation, not shown in the bottom bar. */
object Routes {
    const val QUIZ_RESULT = "quiz_result/{score}/{total}/{xp}"
    const val FAVORITES = "favorites"
    const val MAP = "map"
    const val SETTINGS = "settings"

    fun quizResult(score: Int, total: Int, xp: Int) = "quiz_result/$score/$total/$xp"
}
