package com.geodaily.app.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "geodaily_prefs")

enum class ThemeMode { LIGHT, DARK, SYSTEM }

/**
 * Wraps Jetpack DataStore for all lightweight user preferences: theme,
 * notification toggles, difficulty preference, and the (optional, user-
 * supplied) AI tutor API key.
 */
@Singleton
class UserPreferences @Inject constructor(
    private val context: Context
) {
    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val NOTIFICATION_HOUR = stringPreferencesKey("notification_hour")
        val PREFERRED_DIFFICULTY = stringPreferencesKey("preferred_difficulty")
        val AI_API_KEY = stringPreferencesKey("ai_api_key")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
    }

    val themeMode: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        ThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.name)
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    val notificationsEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[Keys.NOTIFICATIONS_ENABLED] ?: true
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    val notificationHour: Flow<Int> = context.dataStore.data.map {
        (it[Keys.NOTIFICATION_HOUR] ?: "9").toInt()
    }

    suspend fun setNotificationHour(hour: Int) {
        context.dataStore.edit { it[Keys.NOTIFICATION_HOUR] = hour.toString() }
    }

    val preferredDifficulty: Flow<String> = context.dataStore.data.map {
        it[Keys.PREFERRED_DIFFICULTY] ?: "MEDIUM"
    }

    suspend fun setPreferredDifficulty(difficulty: String) {
        context.dataStore.edit { it[Keys.PREFERRED_DIFFICULTY] = difficulty }
    }

    /** Optional key the user pastes in Settings so the AI Tutor can call the Claude API. */
    val aiApiKey: Flow<String?> = context.dataStore.data.map { it[Keys.AI_API_KEY] }

    suspend fun setAiApiKey(key: String) {
        context.dataStore.edit { it[Keys.AI_API_KEY] = key }
    }

    val onboardingDone: Flow<Boolean> = context.dataStore.data.map {
        it[Keys.ONBOARDING_DONE] ?: false
    }

    suspend fun setOnboardingDone(done: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_DONE] = done }
    }
}
