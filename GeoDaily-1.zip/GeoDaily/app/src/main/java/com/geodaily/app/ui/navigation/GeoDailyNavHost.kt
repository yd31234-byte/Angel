package com.geodaily.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.geodaily.app.ui.screens.favorites.FavoritesScreen
import com.geodaily.app.ui.screens.home.HomeScreen
import com.geodaily.app.ui.screens.map.MapScreen
import com.geodaily.app.ui.screens.profile.ProfileScreen
import com.geodaily.app.ui.screens.quiz.QuizResultScreen
import com.geodaily.app.ui.screens.quiz.QuizScreen
import com.geodaily.app.ui.screens.search.SearchScreen
import com.geodaily.app.ui.screens.settings.SettingsScreen
import com.geodaily.app.ui.screens.tutor.TutorScreen

@Composable
fun GeoDailyNavHost() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = { GeoDailyBottomBar(navController) }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = androidx.compose.ui.Modifier.padding(padding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onStartQuiz = { navController.navigate(Screen.Quiz.route) },
                    onOpenMap = { navController.navigate(Routes.MAP) },
                    onOpenFavorites = { navController.navigate(Routes.FAVORITES) }
                )
            }
            composable(Screen.Quiz.route) {
                QuizScreen(
                    onFinished = { score, total, xp ->
                        navController.navigate(Routes.quizResult(score, total, xp)) {
                            popUpTo(Screen.Quiz.route) { inclusive = true }
                        }
                    }
                )
            }
            composable(
                route = Routes.QUIZ_RESULT,
                arguments = listOf(
                    navArgument("score") { type = NavType.IntType },
                    navArgument("total") { type = NavType.IntType },
                    navArgument("xp") { type = NavType.IntType }
                )
            ) { backStackEntry ->
                val score = backStackEntry.arguments?.getInt("score") ?: 0
                val total = backStackEntry.arguments?.getInt("total") ?: 0
                val xp = backStackEntry.arguments?.getInt("xp") ?: 0
                QuizResultScreen(
                    score = score, total = total, xp = xp,
                    onDone = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Home.route) { inclusive = true }
                        }
                    }
                )
            }
            composable(Screen.Tutor.route) {
                TutorScreen(onOpenSettings = { navController.navigate(Routes.SETTINGS) })
            }
            composable(Screen.Search.route) {
                SearchScreen(onOpenMap = { navController.navigate(Routes.MAP) })
            }
            composable(Screen.Profile.route) {
                ProfileScreen(onOpenSettings = { navController.navigate(Routes.SETTINGS) })
            }
            composable(Routes.FAVORITES) {
                FavoritesScreen(onBack = { navController.popBackStack() })
            }
            composable(Routes.MAP) {
                MapScreen(onBack = { navController.popBackStack() })
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}

@Composable
private fun GeoDailyBottomBar(navController: androidx.navigation.NavController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    // Only show the bottom bar on top-level destinations.
    val showBottomBar = Screen.bottomBarScreens.any { screen ->
        currentDestination?.hierarchy?.any { it.route == screen.route } == true
    }
    if (!showBottomBar) return

    NavigationBar {
        Screen.bottomBarScreens.forEach { screen ->
            val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { androidx.compose.material3.Icon(screen.icon, contentDescription = screen.label) },
                label = { Text(screen.label) }
            )
        }
    }
}
