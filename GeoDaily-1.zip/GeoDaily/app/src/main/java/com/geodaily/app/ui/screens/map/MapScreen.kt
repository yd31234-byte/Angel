package com.geodaily.app.ui.screens.map

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class Continent(val name: String, val highlight: String)

private val continents = listOf(
    Continent("Africa", "Home to the Sahara, the Nile, and the Great Rift Valley."),
    Continent("Asia", "The largest and most populous continent, home to Everest."),
    Continent("Europe", "Known for the Alps, the Danube, and dense country borders."),
    Continent("North America", "Spans arctic tundra to tropical coastlines."),
    Continent("South America", "Home to the Amazon rainforest and the Andes."),
    Continent("Australia/Oceania", "The world's smallest continent and largest island, Australia."),
    Continent("Antarctica", "Earth's coldest, driest, and windiest continent.")
)

/**
 * A lightweight interactive "map" implemented as an explorable continent list.
 * This keeps the feature fully offline and dependency-free; swap in a tile-based
 * map library (e.g. Mapbox/Google Maps SDK) here later for full pan/zoom.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(onBack: () -> Unit) {
    var selected by remember { mutableStateOf<Continent?>(null) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("World Map") },
            navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
            }
        )
    }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(continents) { continent ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    onClick = { selected = if (selected == continent) null else continent },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Icon(Icons.Filled.Public, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(continent.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        if (selected == continent) {
                            Spacer(Modifier.height(8.dp))
                            Text(continent.highlight, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}
