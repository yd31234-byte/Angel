package com.geodaily.app.data.local.dao

import androidx.room.*
import com.geodaily.app.data.local.entity.AchievementEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AchievementDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(achievements: List<AchievementEntity>)

    @Query("SELECT * FROM achievements ORDER BY requiredValue ASC")
    fun getAllAchievements(): Flow<List<AchievementEntity>>

    @Query("SELECT * FROM achievements WHERE type = :type AND isUnlocked = 0 ORDER BY requiredValue ASC")
    suspend fun getLockedByType(type: String): List<AchievementEntity>

    @Query("UPDATE achievements SET isUnlocked = 1, unlockedAtEpochDay = :epochDay WHERE id = :id")
    suspend fun unlock(id: String, epochDay: Long)

    @Query("SELECT COUNT(*) FROM achievements")
    suspend fun count(): Int
}
