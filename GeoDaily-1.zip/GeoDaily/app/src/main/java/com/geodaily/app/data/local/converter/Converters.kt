package com.geodaily.app.data.local.converter

import androidx.room.TypeConverter

/**
 * Room type converters. Lists of strings (e.g. quiz options) are stored as a
 * single delimited string using a delimiter unlikely to appear in real content.
 */
class Converters {

    private val delimiter = "||"

    @TypeConverter
    fun fromStringList(list: List<String>): String = list.joinToString(delimiter)

    @TypeConverter
    fun toStringList(data: String): List<String> =
        if (data.isEmpty()) emptyList() else data.split(delimiter)
}
