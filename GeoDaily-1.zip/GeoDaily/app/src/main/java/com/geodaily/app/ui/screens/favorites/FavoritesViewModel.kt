package com.geodaily.app.ui.screens.favorites

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.geodaily.app.data.local.entity.FactEntity
import com.geodaily.app.data.repository.FactRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FavoritesViewModel @Inject constructor(
    private val factRepository: FactRepository
) : ViewModel() {

    val favorites: StateFlow<List<FactEntity>> = factRepository.getFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun removeFavorite(factId: Long) {
        viewModelScope.launch { factRepository.toggleFavorite(factId, false) }
    }
}
