package com.geodaily.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A single message in the AI Geography Tutor conversation history. */
@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val content: String,
    val isFromUser: Boolean,
    val timestamp: Long
)
