package com.geodaily.app.data.local

import com.geodaily.app.data.local.entity.FactEntity

/**
 * Offline-first content library of geography facts.
 * [dayIndex] (0-based) is used to deterministically pick "today's fact" via
 * (dayOfYear % facts.size), so the rotation continues indefinitely and works
 * with zero network access.
 */
object SeedFacts {

    fun all(): List<FactEntity> = listOf(
        FactEntity(title = "The Widest River", description = "The Amazon River discharges more water than the next seven largest rivers combined, and during the wet season it can swell to over 24 miles wide.", category = "Rivers", dayIndex = 0),
        FactEntity(title = "A Country That Spans Two Continents", description = "Russia stretches across eleven time zones and touches both Europe and Asia, making it the only country to span such a vast range of longitudes.", category = "Countries", dayIndex = 1),
        FactEntity(title = "The Driest Place on Earth", description = "Parts of the Atacama Desert in Chile have received no recorded rainfall for decades, making it drier than most deserts, including sections of the Sahara.", category = "Deserts", dayIndex = 2),
        FactEntity(title = "Earth's Tallest Mountain from Base to Peak", description = "While Everest has the highest elevation above sea level, Mauna Kea in Hawaii is taller when measured from its base on the ocean floor to its summit.", category = "Mountains", dayIndex = 3),
        FactEntity(title = "A Capital Higher Than the Clouds", description = "La Paz, Bolivia's administrative capital, sits at roughly 3,650 meters above sea level, making it the highest capital city in the world.", category = "Capitals", dayIndex = 4),
        FactEntity(title = "The Ocean's Deepest Point", description = "The Challenger Deep in the Mariana Trench plunges nearly 11,000 meters down, deep enough to submerge Mount Everest with room to spare.", category = "Oceans", dayIndex = 5),
        FactEntity(title = "A Volcano That Reshaped an Island", description = "The 1883 eruption of Krakatoa was so powerful it was heard thousands of kilometers away and altered global temperatures for years afterward.", category = "Volcanoes", dayIndex = 6),
        FactEntity(title = "The Ring of Fire", description = "About 75 percent of the world's active volcanoes lie along the Pacific Ring of Fire, a horseshoe-shaped belt circling the Pacific Ocean.", category = "Geology", dayIndex = 7),
        FactEntity(title = "A Desert That Isn't Hot", description = "Antarctica is technically the largest desert on Earth by area, since 'desert' refers to low precipitation rather than temperature.", category = "Deserts", dayIndex = 8),
        FactEntity(title = "The Smallest Country", description = "Vatican City covers just 0.49 square kilometers, making it smaller than most golf courses yet fully sovereign.", category = "Countries", dayIndex = 9),
        FactEntity(title = "A River That Flows Backward (Sort Of)", description = "The Chicago River's flow was engineered to reverse direction in 1900, sending wastewater away from Lake Michigan instead of into it.", category = "Rivers", dayIndex = 10),
        FactEntity(title = "The Longest Mountain Range", description = "The Andes stretch about 7,000 kilometers along South America's western edge, making them the longest continental mountain range on Earth.", category = "Mountains", dayIndex = 11),
        FactEntity(title = "A Flag with No Straight Lines... Almost", description = "Nepal's flag is the only national flag that isn't rectangular, made of two stacked triangular pennants representing the Himalayas.", category = "Flags", dayIndex = 12),
        FactEntity(title = "Wildlife Found Nowhere Else", description = "Madagascar separated from mainland Africa around 88 million years ago, so over 90 percent of its wildlife, like lemurs, exists nowhere else on Earth.", category = "Wildlife", dayIndex = 13),
        FactEntity(title = "A Lake Bigger Than Some Seas", description = "The Caspian Sea is technically the world's largest inland body of water, so large it's classified as both a sea and a lake.", category = "Oceans", dayIndex = 14),
        FactEntity(title = "Earth's Shifting Plates", description = "Tectonic plates move roughly at the speed fingernails grow, a few centimeters per year, yet over millions of years this reshapes entire continents.", category = "Geology", dayIndex = 15),
        FactEntity(title = "A Country of Over 17,000 Islands", description = "Indonesia is made up of more than 17,000 islands, though only around 6,000 of them are inhabited.", category = "Maps", dayIndex = 16),
        FactEntity(title = "The Coldest Inhabited Place", description = "The Siberian town of Oymyakon has recorded temperatures below -60°C, yet it remains permanently inhabited.", category = "Climate", dayIndex = 17),
        FactEntity(title = "A Landmark Built to Align with the Sun", description = "During the equinoxes, sunlight at Chichen Itza's pyramid creates a shadow resembling a serpent slithering down the staircase.", category = "Landmarks", dayIndex = 18),
        FactEntity(title = "The World's Longest Coastline", description = "Canada has the longest coastline of any country, spanning roughly 202,000 kilometers thanks to its many islands and inlets.", category = "Countries", dayIndex = 19),
        FactEntity(title = "A Desert That Was Once an Ocean Floor", description = "The Sahara was a lush, green savanna with lakes and rivers as recently as 6,000 years ago, before a shift in Earth's orbit dried it out.", category = "Deserts", dayIndex = 20),
        FactEntity(title = "The Highest Waterfall", description = "Angel Falls in Venezuela drops 979 meters, roughly 15 times the height of Niagara Falls, from the edge of a tabletop mountain.", category = "Landmarks", dayIndex = 21),
        FactEntity(title = "A River Shared by Ten Countries", description = "The Danube flows through more countries than any other river in the world, connecting Central and Eastern Europe.", category = "Rivers", dayIndex = 22),
        FactEntity(title = "An Ocean Current That Shapes Climate", description = "The Gulf Stream carries warm water from the Gulf of Mexico to Western Europe, keeping cities like London milder than their latitude suggests.", category = "Climate", dayIndex = 23),
        FactEntity(title = "The Youngest Mountain Range", description = "The Himalayas are still growing by a few millimeters each year as the Indian and Eurasian tectonic plates continue to collide.", category = "Mountains", dayIndex = 24),
        FactEntity(title = "A Country with No Rivers", description = "Saudi Arabia has no permanent rivers or lakes, relying instead on groundwater, desalination, and seasonal wadis.", category = "Countries", dayIndex = 25),
        FactEntity(title = "The Great Barrier Reef's True Scale", description = "It stretches over 2,300 kilometers and is the only living structure on Earth visible from space.", category = "Oceans", dayIndex = 26),
        FactEntity(title = "A Volcano That Never Truly Sleeps", description = "Mount Stromboli off Italy's coast has been erupting almost continuously for over 2,000 years, earning it the nickname 'Lighthouse of the Mediterranean.'", category = "Volcanoes", dayIndex = 27),
        FactEntity(title = "Migration Across a Continent", description = "The Serengeti hosts the largest terrestrial mammal migration on Earth, with over a million wildebeest moving in a continuous annual cycle.", category = "Wildlife", dayIndex = 28),
        FactEntity(title = "A Capital That Isn't the Largest City", description = "Many countries separate their political capital from their largest city; for example, Canberra, not Sydney, is Australia's capital.", category = "Capitals", dayIndex = 29)
    )
}
