package com.geodaily.app.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.geodaily.app.data.datastore.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var apiKeyInput by remember(state.apiKey) { mutableStateOf(state.apiKey) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Settings") },
            navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
            }
        )
    }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            SettingsSection(title = "Appearance") {
                ThemeMode.entries.forEach { mode ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(mode.name.lowercase().replaceFirstChar { it.uppercase() })
                        RadioButton(
                            selected = state.themeMode == mode,
                            onClick = { viewModel.setThemeMode(mode) }
                        )
                    }
                }
            }

            SettingsSection(title = "Daily Reminders") {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Enable notifications")
                    Switch(
                        checked = state.notificationsEnabled,
                        onCheckedChange = viewModel::setNotificationsEnabled
                    )
                }
                if (state.notificationsEnabled) {
                    Text("Reminder time: ${state.notificationHour}:00", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = state.notificationHour.toFloat(),
                        onValueChange = { viewModel.setNotificationHour(it.toInt()) },
                        valueRange = 6f..21f,
                        steps = 14
                    )
                }
            }

            SettingsSection(title = "Quiz Difficulty Preference") {
                listOf("EASY", "MEDIUM", "HARD").forEach { difficulty ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(difficulty)
                        RadioButton(
                            selected = state.preferredDifficulty == difficulty,
                            onClick = { viewModel.setPreferredDifficulty(difficulty) }
                        )
                    }
                }
            }

            SettingsSection(title = "AI Tutor") {
                Text(
                    "Paste a Claude API key to enable the AI Geography Tutor. Get one at console.anthropic.com. It's stored only on this device.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Claude API Key") },
                    singleLine = true,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = { viewModel.setApiKey(apiKeyInput) }) { Text("Save Key") }
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Card { Column(Modifier.padding(16.dp), content = content) }
    }
}
