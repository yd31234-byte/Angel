package com.geodaily.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single multiple-choice geography question.
 * [options] is stored as a delimited string via QuizConverters.
 */
@Entity(tableName = "quiz_questions")
data class QuizQuestionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val question: String,
    val options: List<String>,
    val correctOptionIndex: Int,
    val explanation: String,
    val difficulty: String, // EASY, MEDIUM, HARD
    val category: String,
    val dayIndex: Int
)
