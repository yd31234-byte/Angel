package com.geodaily.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a single geography fact shown to the user.
 * [dayIndex] maps a fact to a calendar day-of-year bucket so the app can
 * deterministically pick "today's fact" even fully offline.
 */
@Entity(tableName = "facts")
data class FactEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val category: String,
    val imageUrl: String? = null,
    val dayIndex: Int,
    val isFavorite: Boolean = false
)
