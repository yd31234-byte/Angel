package com.geodaily.app.data.repository

import com.geodaily.app.data.local.SeedFacts
import com.geodaily.app.data.local.dao.FactDao
import com.geodaily.app.data.local.entity.FactEntity
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.temporal.ChronoField
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FactRepository @Inject constructor(
    private val factDao: FactDao
) {
    /** Populates the local database with the offline fact library on first launch. */
    suspend fun seedIfNeeded() {
        if (factDao.count() == 0) {
            factDao.insertAll(SeedFacts.all())
        }
    }

    /** Deterministically resolves "today's fact" from the day of year, so it repeats offline forever. */
    suspend fun getTodayFact(): FactEntity? {
        val dayOfYear = LocalDate.now().get(ChronoField.DAY_OF_YEAR)
        val total = maxOf(factDao.count(), 1)
        return factDao.getFactForDay(dayOfYear % total) ?: SeedFacts.all().firstOrNull()
    }

    fun getAllFacts(): Flow<List<FactEntity>> = factDao.getAllFacts()

    fun getFavorites(): Flow<List<FactEntity>> = factDao.getFavoriteFacts()

    fun search(query: String): Flow<List<FactEntity>> = factDao.searchFacts(query)

    suspend fun toggleFavorite(factId: Long, isFavorite: Boolean) =
        factDao.setFavorite(factId, isFavorite)
}
