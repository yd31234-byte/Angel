# Add project specific ProGuard rules here.
-keep class com.geodaily.app.data.local.entity.** { *; }
-keep class com.geodaily.app.data.remote.** { *; }
-keepattributes *Annotation*
