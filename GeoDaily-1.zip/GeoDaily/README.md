# GeoDaily

A modern Android geography learning app built with Kotlin, Jetpack Compose, and Material 3.

## Features
- Daily geography fact (rotates deterministically, works fully offline)
- Daily 10-question quiz with Easy/Medium/Hard difficulty, explanations, and history
- AI Geography Tutor chat (calls the Claude API using your own API key)
- XP, levels, streaks, and unlockable achievement badges
- Favorites, search/explore, a simple interactive world map
- Light/dark/system theme, Material You dynamic color on Android 12+
- Daily reminder notification via WorkManager

## Tech stack
- Kotlin + Jetpack Compose + Material 3
- MVVM architecture
- Room (offline storage), DataStore (preferences)
- Hilt (dependency injection)
- Navigation Compose
- Retrofit + OkHttp (AI Tutor networking only)
- WorkManager (daily notification)

## Getting started

1. **Requirements**: Android Studio Koala (2024.1.1) or newer, JDK 17.
2. Open this folder directly in Android Studio (`File > Open`).
3. Let Gradle sync — it will download dependencies on first sync (internet required).
4. Run on an emulator or device with Android 8.0 (API 26) or higher.

No API keys are required for daily facts, the quiz, favorites, search, the map, or
achievements — all of that content is seeded locally and works fully offline.

## Enabling the AI Tutor

The AI Tutor calls the Claude API (`api.anthropic.com`) directly from the device using a
key you provide — no key is bundled with the app.

1. Get an API key at https://console.anthropic.com
2. In the app, go to **Profile → Settings → AI Tutor**, paste the key, and tap **Save Key**.
3. The key is stored locally on-device via DataStore; it is not sent anywhere except in
   request headers to `api.anthropic.com`.

## Project structure

```
app/src/main/java/com/geodaily/app/
├── data/
│   ├── local/          Room entities, DAOs, database, offline seed content
│   ├── datastore/      User preferences (theme, notifications, API key)
│   ├── remote/         Retrofit models/service for the AI Tutor
│   └── repository/     FactRepository, QuizRepository, StatsRepository, ChatRepository
├── di/                 Hilt modules (database, network, datastore)
├── ui/
│   ├── theme/          Material 3 color scheme, typography
│   ├── navigation/      NavHost + bottom navigation
│   └── screens/        One package per feature (home, quiz, tutor, profile, ...)
└── worker/             WorkManager daily reminder + boot receiver
```

## Notes and known limitations

- The "interactive world map" ships as a lightweight continent explorer with zero external
  dependencies so the app stays fully offline-capable out of the box. Swap in the Google
  Maps SDK or Mapbox in `ui/screens/map/MapScreen.kt` for full pan/zoom/pin functionality.
- The offline content library ships with 30 facts and 60 quiz questions across all three
  difficulties, rotating by day-of-year so the app never runs out of "new" content — add
  more entries to `SeedFacts.kt` / `SeedQuiz.kt` any time to expand the library.
- This project was generated outside of Android Studio, so while the code was written and
  reviewed carefully for correctness, please do a Gradle sync and a first build yourself
  and let me know if anything needs adjusting — happy to fix it.
